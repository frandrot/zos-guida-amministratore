/* Public browser settings; no secret/service_role credentials. */
window.ZOS_CLOUD_CONFIG = Object.freeze({"supabaseUrl": "https://rdmogdsycnxqwdyrnygw.supabase.co", "publishableKey": "sb_publishable_LFc-1Uh-FEaw9g8kNHURJw_67PAeO2o", "allowRegistration": true});
