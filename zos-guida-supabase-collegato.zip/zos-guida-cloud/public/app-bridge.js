/* Bridge to the original guide. Keeps its modules, quiz, console and mascot. */
(() => {
'use strict';
const clone=v=>JSON.parse(JSON.stringify(v));
const quizDefault=()=>({i:0,score:0,ans:null,selected:null,answers:[],fin:false});
const builderDefault=()=>({job:'ALLOC',dsn:'&SYSUID..TEST.DATA',type:'PS',unit:'TRK',p:5,s:5,dir:10,recfm:'FB',lrecl:80});
function clean(key,value){
 if(!ZOSStore.keys.includes(key)||JSON.stringify(value).length>524288)throw Error('invalid');
 if(['masMuted','masSeen'].includes(key)){if(typeof value!=='boolean')throw Error('invalid');return value;}
 if(key==='lang'){if(!['it','es','en'].includes(value))throw Error('invalid');return value;}
 if(key==='theme'){if(!['light','dark'].includes(value))throw Error('invalid');return value;}
 if(key==='best'){if(value!==null&&(!Number.isInteger(value)||value<0||value>Q.length))throw Error('invalid');return value;}
 if(key==='done'){if(!Array.isArray(value))throw Error('invalid');return [...new Set(value.filter(id=>S.some(s=>s.id===id)))];}
 if(key==='builder'){
  if(!value||typeof value!=='object'||Array.isArray(value))throw Error('invalid');
  const out=builderDefault();
  for(const k of ['job','dsn'])if(typeof value[k]==='string')out[k]=value[k].slice(0,k==='job'?8:100);
  for(const [k,list] of Object.entries({type:['PS','PDS','PDSE'],unit:['TRK','CYL'],recfm:['F','FB','V','VB']}))if(list.includes(value[k]))out[k]=value[k];
  for(const k of ['p','s','dir','lrecl']){const n=Number(value[k]);if(Number.isInteger(n)&&n>0)out[k]=Math.min(n,k==='lrecl'?32760:99999);}
  return out;
 }
 if(key==='quiz-state'){
  if(!value||typeof value!=='object'||!Array.isArray(value.answers))return quizDefault();
  const choice=v=>Number.isInteger(v)&&v>=0&&v<4?v:null;
  const answers=value.answers.slice(0,Q.length).map(choice),i=Number.isInteger(value.i)&&value.i>=0&&value.i<Q.length?value.i:0;
  const ans=choice(value.ans),checked=ans!==null&&answers[i]===ans?ans:null;
  return {i,ans:checked,selected:checked??choice(value.selected),answers,score:answers.reduce((n,a,j)=>n+(a===Q[j].a?1:0),0),fin:!!value.fin&&answers.length===Q.length&&answers.every(a=>a!==null)};
 }
 if(key==='chat'){
  if(!Array.isArray(value))throw Error('invalid');
  return value.filter(m=>m&&['u','b'].includes(m.r)&&typeof m.t==='string').slice(-30).map(m=>{
   const out={r:m.r,t:m.t.slice(0,8000)};
   if(typeof m.req==='string')out.req=m.req.slice(0,2000);
   if(Array.isArray(m.links))out.links=m.links.filter(l=>l&&['lab','quiz','gloss',...S.map(s=>s.id)].includes(l.id)).slice(0,3).map(l=>({id:l.id,g:String(l.g||'').slice(0,100),title:String(l.title||'').slice(0,200),tag:String(l.tag||'').slice(0,40)}));
   return out;
  });
 }
 if(key==='lab-v1'){
  if(!value||typeof value!=='object'||Array.isArray(value)||value.version!==1)throw Error('invalid');
  return clone(value); // The original labLoad performs the structural validation.
 }
 throw Error('invalid');
}
window.ZOSApp={
 clean,
 hydrate(){
  ZOSStore.quiet(()=>{
   const safe={};for(const [key,value]of Object.entries(ZOSStore.dump()))try{safe[key]=clean(key,value);}catch{}
   ZOSStore.replace(safe);
   lang=store.get('lang',document.documentElement.lang||'it');if(!['it','es','en'].includes(lang))lang='it';
   theme=store.get('theme','dark');done=new Set(store.get('done',[]));best=store.get('best',null);
   const b=store.get('builder',builderDefault());for(const k of Object.keys(builderDefault()))B[k]=b[k];
   quiz=store.get('quiz-state',quizDefault());lab=labLoad();labHistoryIndex=lab.history.length;labDraft='';
   chat.msgs=store.get('chat',[]);chat.open=false;chat.status=null;chat.req={name:'',mail:'',kind:'new',msg:''};
   mas.muted=store.get('masMuted',false);renderAll(true);
  });
 },
 snapshot(){return {...ZOSStore.dump(),lang,theme,done:[...done],best,builder:clone(B),'quiz-state':clone(quiz),'lab-v1':clone(lab),chat:clone(chat.msgs)};},
 closeAssistant(){chat.open=false;chatRender();},
 openAssistant(){chat.open=true;chat.tab='chat';chatRender();}
};
const previousChat=window.chatRender;
window.chatRender=function(){previousChat();window.ZOSOnline?.refreshLabels();};
// Record a selection as well as a checked answer: unfinished quizzes resume.
document.addEventListener('change',e=>{if(e.target.name==='quiz-choice')store.set('quiz-state',quiz);});
})();
