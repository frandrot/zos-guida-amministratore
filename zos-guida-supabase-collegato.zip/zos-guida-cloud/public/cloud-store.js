/* The database is authoritative. Study data stays in memory until the server
   acknowledges it; only UI preferences and the authentication session use storage. */
(() => {
  'use strict';
  const keys = ['lang','theme','done','best','builder','lab-v1','quiz-state','chat','masMuted','masSeen'];
  const allowed = new Set(keys);
  let state = Object.create(null), silent = 0;
  const clone = x => x === undefined ? undefined : JSON.parse(JSON.stringify(x));
  for (const key of ['lang','theme']) {
    try { const raw = localStorage.getItem('zoscloud:ui:'+key); if(raw) state[key]=JSON.parse(raw); } catch {}
  }
  window.ZOSStore = {
    keys,
    get(key, fallback) { return Object.hasOwn(state,key) ? clone(state[key]) : clone(fallback); },
    set(key, value) {
      if (!allowed.has(key)) return;
      const copy=clone(value);
      if (JSON.stringify(state[key])===JSON.stringify(copy)) return;
      state[key]=copy;
      if (['lang','theme'].includes(key)) try { localStorage.setItem('zoscloud:ui:'+key, JSON.stringify(copy)); } catch {}
      if (!silent) window.dispatchEvent(new CustomEvent('zos:change',{detail:{key,value:clone(copy)}}));
    },
    dump() { return clone(state); },
    replace(next) {
      state=Object.create(null);
      for (const key of keys) if (Object.hasOwn(next,key)) state[key]=clone(next[key]);
    },
    quiet(fn) { silent++; try { return fn(); } finally { silent--; } },
    legacy() {
      const data={};
      for (const key of keys) try {
        const raw=localStorage.getItem('zosguida:'+key);
        if(raw!==null) data[key]=JSON.parse(raw);
      } catch {}
      return data;
    }
  };
})();
