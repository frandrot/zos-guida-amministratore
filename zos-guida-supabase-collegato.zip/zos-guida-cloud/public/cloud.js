/* z/OS Online. No secret keys, no service-role client, no fabricated chat replies.
   Every successful save shown in the UI requires a successful database response. */
(() => {
'use strict';
const C=window.ZOS_CLOUD_CONFIG||{}, store=window.ZOSStore;
const I={
it:{title:'Il tuo spazio z/OS',account:'Account e salvataggi',room:'Chat online',guide:'Cerca nella guida',close:'Chiudi',guest:'Solo questa sessione',setup:'Cloud da configurare',loading:'Collegamento…',saving:'Salvataggio…',saved:'Salvato sul server',connected:'Cloud collegato',error:'Salvataggio non confermato',conflict:'Conflitto tra dispositivi',login:'Accedi',signup:'Crea account',logout:'Esci',email:'Email',password:'Password',name:'Nome nella chat',reset:'Password dimenticata',sendReset:'Invia link di recupero',newPassword:'Nuova password',updatePassword:'Aggiorna password',intro:'Accedi per ritrovare moduli, quiz e console anche da un altro dispositivo.',setupText:'Il sito è pronto per il cloud, ma il database non è ancora collegato. Configura Supabase e il file config.js seguendo le istruzioni del progetto. Finché non compare la conferma del server, gli esercizi di questa sessione non sono salvati online.',authPrivacy:'La password viene gestita da Supabase Auth. I progressi sono privati; nella chat si vede il tuo nome, non la tua email.',memberNote:'Stanza condivisa: i messaggi sono conservati nel database e visibili a tutti gli utenti registrati. Non inserire password o informazioni riservate.',empty:'Nessun messaggio. Inizia tu la conversazione.',loadingMessages:'Caricamento dello storico…',messagePh:'Scrivi un messaggio alla classe…',send:'Invia',sent:'Messaggio salvato sul server.',notSent:'Messaggio non inviato. Il testo è ancora qui: riprova.',delete:'Elimina',deleteConfirm:'Eliminare questo tuo messaggio dalla chat?',older:'Messaggi precedenti',live:'Aggiornamento in tempo reale',poll:'Aggiornamento periodico',loginChat:'Accedi per leggere e scrivere nella chat condivisa.',retry:'Riprova',refresh:'Ricarica dal server',export:'Esporta i miei progressi',import:'Importa progressi da JSON',legacy:'Importa vecchi dati di questo browser',importConfirm:'Importare questi progressi nel tuo account? I campi presenti nel file sostituiranno quelli attuali, dopo la tua conferma.',imported:'Importazione preparata. Attendi la conferma di salvataggio sul server.',noLegacy:'Non ci sono vecchi dati accessibili su questo indirizzo. I dati di un file locale o di un altro sito non sono leggibili da qui.',noAuth:'Accedi prima di salvare o inviare.',checkMail:'Controlla la tua email e conferma l’account prima di accedere. Se il messaggio non arriva, verifica la configurazione email di Supabase.',resetSent:'Se l’indirizzo è registrato, riceverai il link di recupero. Controlla anche la posta indesiderata.',passwordUpdated:'Password aggiornata.',authFailed:'Operazione non riuscita. Controlla i dati e la connessione.',dbFailed:'Database non raggiungibile o schema non configurato. Nessun salvataggio online è stato confermato.',rate:'Troppi invii ravvicinati. Riprova più tardi.',noSaveExit:'Ci sono modifiche non salvate. Risolvi gli errori o i conflitti prima di uscire.',remoteChoice:'Usa la versione sul server',localChoice:'Salva questa versione',conflictText:'Un altro dispositivo ha modificato questi dati. Scegli quale versione conservare; nessuna sovrascrittura è stata effettuata.',last:'Ultimo salvataggio confermato',saveName:'Salva nome',nameSaved:'Nome aggiornato.',privateData:'Progressi personali nel database',privateText:'Moduli studiati, punteggi, risposte, generatore JCL, laboratorio e cronologia dell’assistente sono associati al tuo account. Il laboratorio resta un simulatore: non esegue comandi su un mainframe reale.',offline:'Connessione assente: le nuove modifiche sono in attesa in questa scheda, non ancora sul server. Non chiuderla.',noAI:'Questa è una chat tra persone. «Cerca nella guida» resta una ricerca automatica nei contenuti, non un assistente AI.',badFile:'File non valido o troppo grande. Usa un’esportazione JSON di questa guida.',importAccount:'Accedi per importare i progressi nel tuo account.',readyNote:'Salvataggio associato al tuo account. Ricarica dal server per aggiornare questa scheda con le modifiche di un altro dispositivo.',requestSaved:'Richiesta salvata nel database. Il team può leggerla dal pannello di amministrazione Supabase.',fetchFailed:'Non è stato possibile caricare i messaggi.',configKey:'Configurazione non valida: usa solo URL HTTPS Supabase e chiave publishable (oppure anon). Mai una chiave secret/service_role.',minPassword:'Per un nuovo account usa almeno 12 caratteri.',nameHelp:'Da 2 a 40 caratteri. Il nome è visibile agli altri utenti.',fileNote:'I progressi sono salvati online solo dopo l’accesso e la conferma del server.',signing:'Accesso in corso…'},
es:{title:'Tu espacio z/OS',account:'Cuenta y guardado',room:'Chat en línea',guide:'Buscar en la guía',close:'Cerrar',guest:'Solo esta sesión',setup:'Configurar nube',loading:'Conectando…',saving:'Guardando…',saved:'Guardado en el servidor',connected:'Nube conectada',error:'Guardado sin confirmar',conflict:'Conflicto entre dispositivos',login:'Acceder',signup:'Crear cuenta',logout:'Salir',email:'Correo electrónico',password:'Contraseña',name:'Nombre en el chat',reset:'Olvidé mi contraseña',sendReset:'Enviar enlace',newPassword:'Nueva contraseña',updatePassword:'Actualizar contraseña',intro:'Accede para recuperar módulos, cuestionarios y consola desde otro dispositivo.',setupText:'El sitio está preparado, pero la base de datos todavía no está conectada. Configura Supabase y config.js siguiendo las instrucciones del proyecto. Hasta que el servidor confirme el guardado, esta sesión no está guardada en línea.',authPrivacy:'Supabase Auth gestiona la contraseña. El progreso es privado; en el chat se muestra tu nombre, no tu correo.',memberNote:'Sala compartida: los mensajes se guardan en la base de datos y son visibles para todos los usuarios registrados. No publiques contraseñas ni información confidencial.',empty:'No hay mensajes. Inicia la conversación.',loadingMessages:'Cargando historial…',messagePh:'Escribe un mensaje al grupo…',send:'Enviar',sent:'Mensaje guardado en el servidor.',notSent:'Mensaje no enviado. El texto sigue aquí: vuelve a intentarlo.',delete:'Eliminar',deleteConfirm:'¿Eliminar tu mensaje del chat?',older:'Mensajes anteriores',live:'Actualización en tiempo real',poll:'Actualización periódica',loginChat:'Accede para leer y escribir en el chat compartido.',retry:'Reintentar',refresh:'Recargar del servidor',export:'Exportar mi progreso',import:'Importar progreso JSON',legacy:'Importar datos antiguos de este navegador',importConfirm:'¿Importar este progreso? Los campos presentes sustituirán los actuales tras tu confirmación.',imported:'Importación preparada. Espera la confirmación del servidor.',noLegacy:'No hay datos antiguos accesibles en esta dirección. No se pueden leer datos de un archivo local o de otro sitio.',noAuth:'Accede antes de guardar o enviar.',checkMail:'Confirma tu cuenta desde el correo electrónico. Si no llega, revisa la configuración de correo de Supabase.',resetSent:'Si la dirección está registrada, recibirás el enlace de recuperación. Revisa también el correo no deseado.',passwordUpdated:'Contraseña actualizada.',authFailed:'No se pudo completar la operación. Comprueba los datos y la conexión.',dbFailed:'Base de datos no disponible o esquema sin configurar. No se ha confirmado ningún guardado en línea.',rate:'Demasiados envíos seguidos. Inténtalo más tarde.',noSaveExit:'Hay cambios sin guardar. Resuelve los errores o conflictos antes de salir.',remoteChoice:'Usar versión del servidor',localChoice:'Guardar esta versión',conflictText:'Otro dispositivo ha cambiado estos datos. Elige la versión que deseas conservar; no se ha sobrescrito nada.',last:'Último guardado confirmado',saveName:'Guardar nombre',nameSaved:'Nombre actualizado.',privateData:'Progreso personal en la base de datos',privateText:'Los módulos, resultados, respuestas, generador JCL, laboratorio e historial del asistente pertenecen a tu cuenta. El laboratorio sigue siendo un simulador y no ejecuta comandos en un mainframe real.',offline:'Sin conexión: los cambios nuevos están pendientes en esta pestaña, todavía no en el servidor. No la cierres.',noAI:'Este es un chat entre personas. «Buscar en la guía» consulta contenidos y no es un asistente de IA.',badFile:'Archivo no válido o demasiado grande. Usa una exportación JSON de esta guía.',importAccount:'Accede para importar progreso en tu cuenta.',readyNote:'Guardado asociado a tu cuenta. Recarga del servidor para ver los cambios de otro dispositivo.',requestSaved:'Solicitud guardada. El equipo puede verla en el panel de administración de Supabase.',fetchFailed:'No se han podido cargar los mensajes.',configKey:'Configuración no válida: usa URL HTTPS de Supabase y clave publishable o anon. Nunca secret/service_role.',minPassword:'Usa al menos 12 caracteres para una cuenta nueva.',nameHelp:'De 2 a 40 caracteres. El nombre es visible para otros usuarios.',fileNote:'El progreso solo se guarda en línea al acceder y recibir la confirmación del servidor.',signing:'Accediendo…'},
en:{title:'Your z/OS space',account:'Account & saves',room:'Online chat',guide:'Search the guide',close:'Close',guest:'This session only',setup:'Cloud setup needed',loading:'Connecting…',saving:'Saving…',saved:'Saved on server',connected:'Cloud connected',error:'Save not confirmed',conflict:'Device conflict',login:'Sign in',signup:'Create account',logout:'Sign out',email:'Email',password:'Password',name:'Chat name',reset:'Forgot password',sendReset:'Send reset link',newPassword:'New password',updatePassword:'Update password',intro:'Sign in to access your modules, quiz and console on another device.',setupText:'The site is cloud-ready, but the database is not connected yet. Configure Supabase and config.js using the project instructions. This session is not saved online until the server confirms a save.',authPrivacy:'Supabase Auth manages passwords. Progress is private. Chat shows your name, not your email.',memberNote:'Shared room: messages are stored in the database and visible to all registered users. Do not post passwords or confidential information.',empty:'No messages yet. Start the conversation.',loadingMessages:'Loading history…',messagePh:'Write a message to the group…',send:'Send',sent:'Message saved on the server.',notSent:'Message not sent. Your text is still here; try again.',delete:'Delete',deleteConfirm:'Delete your message from the chat?',older:'Earlier messages',live:'Real-time updates',poll:'Periodic updates',loginChat:'Sign in to read and write in the shared chat.',retry:'Retry',refresh:'Reload from server',export:'Export my progress',import:'Import JSON progress',legacy:'Import old data from this browser',importConfirm:'Import this progress? Fields in the file will replace your current values after confirmation.',imported:'Import prepared. Wait for the server save confirmation.',noLegacy:'No old data is accessible at this address. Data from a local file or another website cannot be read here.',noAuth:'Sign in before saving or sending.',checkMail:'Check your email and confirm your account before signing in. If no email arrives, check Supabase email configuration.',resetSent:'If the address is registered, you will receive a reset link. Check your spam folder too.',passwordUpdated:'Password updated.',authFailed:'The operation failed. Check your details and connection.',dbFailed:'Database unavailable or schema not configured. No online save has been confirmed.',rate:'Too many messages. Try again later.',noSaveExit:'There are unsaved changes. Resolve errors or conflicts before signing out.',remoteChoice:'Use server version',localChoice:'Save this version',conflictText:'Another device changed these values. Choose which version to keep; nothing has been overwritten.',last:'Last confirmed save',saveName:'Save name',nameSaved:'Name updated.',privateData:'Private study progress in the database',privateText:'Modules, scores, answers, JCL builder, lab and guide-assistant history belong to your account. The lab is still a simulator; it does not execute commands on a real mainframe.',offline:'Offline: new changes are pending in this tab, not saved on the server yet. Do not close it.',noAI:'This is a chat between people. “Search the guide” is content lookup, not an AI assistant.',badFile:'Invalid or oversized file. Use a JSON export from this guide.',importAccount:'Sign in to import progress into your account.',readyNote:'Saves belong to your account. Reload from the server to see another device’s changes in this tab.',requestSaved:'Request saved in the database. The team can read it in the Supabase administration dashboard.',fetchFailed:'Messages could not be loaded.',configKey:'Invalid configuration: use a Supabase HTTPS URL and a publishable or anon key. Never a secret/service_role key.',minPassword:'Use at least 12 characters for a new account.',nameHelp:'2 to 40 characters. Other users can see this name.',fileNote:'Progress is saved online only after sign-in and server confirmation.',signing:'Signing in…'}
};
const L=()=>['it','es','en'].includes(document.documentElement.lang)?document.documentElement.lang:'it';
const t=k=>(I[L()][k]||I.it[k]||k), esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const $=id=>document.getElementById(id), clone=x=>JSON.parse(JSON.stringify(x));
let client=null,user=null,ready=false,loading=false,epoch=0,flushTask=null;
let pending=new Map(),versions=new Map(),conflicts=new Map(),serial=0;
let lastSaved=null,lastError='',timer=null,retryTimer=null,channel=null,realtime=false;
let messages=[],messagesLoaded=false,chatDraft='',clientId=null,clientDraft='',tab='account',authMode='login',recovery=false,profileName='';
let configValid=false,configMissing=!C.supabaseUrl||!C.publishableKey;
function keyValid(key){
 if(typeof key!=='string'||key.startsWith('sb_secret_'))return false;
 if(/^sb_publishable_[A-Za-z0-9_-]+$/.test(key))return true;
 try {let s=key.split('.')[1].replace(/-/g,'+').replace(/_/g,'/');return JSON.parse(atob(s)).role==='anon';}catch{return false;}
}
try{const u=new URL(C.supabaseUrl);configValid=u.protocol==='https:'&&/^[a-z0-9-]+\.supabase\.co$/i.test(u.hostname)&&keyValid(C.publishableKey);}catch{}
const dialog=document.createElement('dialog');dialog.id='cloudDialog';dialog.className='cloud-dialog';dialog.setAttribute('aria-labelledby','cloudTitle');document.body.append(dialog);
function status(){if(!configValid)return 'setup';if(loading)return 'loading';if(!user)return 'guest';if(conflicts.size)return 'conflict';if(lastError||!navigator.onLine)return 'error';if(pending.size||flushTask)return 'saving';return lastSaved?'saved':'connected';}
function statusText(){return t(status());}
function note(text,kind='info'){const el=$('cloudNotice');if(el){el.textContent=text;el.hidden=!text;el.dataset.kind=kind;}}
function updateStatus(){
 let pill=$('cloudAccount');if(!pill){pill=document.createElement('button');pill.id='cloudAccount';pill.className='cloud-pill';pill.type='button';pill.dataset.cloud='account';document.querySelector('.top')?.append(pill);}
 pill.textContent=statusText();pill.dataset.state=status();pill.title=t('account');
 const sync=$('cloudSyncStatus');if(sync)sync.textContent=!navigator.onLine&&pending.size?t('offline'):lastError?t(lastError):(lastSaved?t('last')+': '+new Date(lastSaved).toLocaleString(L()):t('fileNote'));
 const live=$('cloudLive');if(live){live.textContent=t(realtime?'live':'poll');live.dataset.live=String(realtime);}
 if($('chatFabTxt'))$('chatFabTxt').textContent=t('room');
 if(!document.getElementById('cloudStrip')){
  const strip=document.createElement('div');strip.id='cloudStrip';strip.className='cloud-strip';document.getElementById('main')?.prepend(strip);
 }
 const strip=$('cloudStrip');if(strip)strip.innerHTML=`<div><b>${esc(statusText())}</b><span>${esc(!configValid?t('setupText'):user?t('readyNote'):t('intro'))}</span></div><button class="btn" data-cloud="account">${esc(user?t('account'):t('login'))}</button>`;
 document.querySelectorAll('[data-cloud-label=room]').forEach(e=>e.textContent=t('room'));
 document.querySelectorAll('[data-cloud-label=account]').forEach(e=>e.textContent=t('account'));
}
function open(which='account'){tab=which;window.ZOSApp?.closeAssistant();render();if(!dialog.open)dialog.showModal();}
function render(){
 dialog.innerHTML=`<div class="cloud-layout"><header class="cloud-head"><div><b id="cloudTitle">${esc(t('title'))}</b><small>GITHUB PAGES + SUPABASE</small></div><button class="cloud-close" data-cloud="close" aria-label="${esc(t('close'))}">×</button></header><nav class="cloud-tabs" aria-label="${esc(t('title'))}"><button data-cloud="account" aria-selected="${tab==='account'}">${esc(t('account'))}</button><button data-cloud="room" aria-selected="${tab==='room'}">${esc(t('room'))}</button><button data-cloud="guide">${esc(t('guide'))}</button></nav><section class="cloud-body" id="cloudBody"></section></div>`;
 if(tab==='room'&&user&&ready)renderRoom();else renderAccount(tab==='room');updateStatus();
}
function renderAccount(wantsChat=false){
 const body=$('cloudBody');
 if(!configValid){body.innerHTML=`<h3>${esc(t('setup'))}</h3><div class="cloud-message">${esc(t(configMissing?'setupText':'configKey'))}</div><p>${esc(t('fileNote'))}</p><div class="cloud-actions"><button class="btn" data-cloud="export">${esc(t('export'))}</button><button class="btn" data-cloud="guide">${esc(t('guide'))}</button></div><div id="cloudNotice" hidden></div>`;return;}
 if(loading){body.innerHTML=`<h3>${esc(t('loading'))}</h3><p>${esc(t('intro'))}</p>`;return;}
 if(!user){
  const signup=authMode==='signup',reset=authMode==='reset';
  body.innerHTML=`<h3>${esc(t(wantsChat?'loginChat':signup?'signup':reset?'reset':'login'))}</h3><p>${esc(t('intro'))}</p><form class="cloud-form" id="cloudAuthForm">
  ${signup?`<label>${esc(t('name'))}<input name="name" minlength="2" maxlength="40" required autocomplete="nickname"></label>`:''}
  <label>${esc(t('email'))}<input name="email" type="email" required autocomplete="email" maxlength="254"></label>
  ${!reset?`<label>${esc(t('password'))}<input name="password" type="password" ${signup?'minlength="12"':''} required autocomplete="${signup?'new-password':'current-password'}" maxlength="256"></label>`:''}
  <button class="btn pri" type="submit">${esc(t(signup?'signup':reset?'sendReset':'login'))}</button></form>
  <div class="cloud-actions"><button class="btn" data-cloud="auth-login">${esc(t('login'))}</button>${C.allowRegistration!==false?`<button class="btn" data-cloud="auth-signup">${esc(t('signup'))}</button>`:''}<button class="btn" data-cloud="auth-reset">${esc(t('reset'))}</button></div><div id="cloudNotice" class="cloud-message" role="status" hidden></div><p style="margin-top:18px">${esc(t('authPrivacy'))}</p>`;return;
 }
 const conflictHTML=Array.from(conflicts.entries()).map(([key])=>`<div class="cloud-card"><h4>${esc(key)}</h4><p>${esc(t('conflictText'))}</p><div class="cloud-actions"><button class="btn" data-cloud="remote" data-key="${esc(key)}">${esc(t('remoteChoice'))}</button><button class="btn pri" data-cloud="local" data-key="${esc(key)}">${esc(t('localChoice'))}</button></div></div>`).join('');
 body.innerHTML=`<h3>${esc(profileName||t('account'))}</h3><p>${esc(user.email||'')}</p><div class="cloud-message" id="cloudSyncStatus" role="status"></div>${conflictHTML}
 ${recovery?`<form class="cloud-form" id="cloudPasswordForm"><label>${esc(t('newPassword'))}<input name="password" type="password" minlength="12" maxlength="256" required autocomplete="new-password"></label><button class="btn pri">${esc(t('updatePassword'))}</button></form>`:''}
 <div class="cloud-card"><h4>${esc(t('privateData'))}</h4><p>${esc(t('privateText'))}</p><div class="cloud-actions"><button class="btn pri" data-cloud="refresh">${esc(t('refresh'))}</button><button class="btn" data-cloud="room">${esc(t('room'))}</button><button class="btn" data-cloud="export">${esc(t('export'))}</button><button class="btn" data-cloud="import">${esc(t('import'))}</button><button class="btn" data-cloud="legacy">${esc(t('legacy'))}</button></div></div>
 <form id="cloudNameForm" class="cloud-form"><label>${esc(t('name'))}<input name="name" value="${esc(profileName)}" minlength="2" maxlength="40" required autocomplete="nickname"></label><small>${esc(t('nameHelp'))}</small><button class="btn">${esc(t('saveName'))}</button></form>
 <div id="cloudNotice" class="cloud-message" role="status" hidden></div><div class="cloud-actions"><button class="btn" data-cloud="logout">${esc(t('logout'))}</button></div>`;
}
function renderRoom(){
 $('cloudBody').innerHTML=`<div class="cloud-room"><div class="cloud-room-note">${esc(t('memberNote'))}<br><span id="cloudLive" class="cloud-live"></span></div><button class="btn" data-cloud="older">${esc(t('older'))}</button><div id="cloudMessages" class="cloud-messages" aria-label="${esc(t('room'))}"></div><form class="cloud-form cloud-compose" id="cloudMessageForm"><textarea name="message" id="cloudMessageInput" rows="2" maxlength="2000" placeholder="${esc(t('messagePh'))}" aria-label="${esc(t('messagePh'))}" required></textarea><button class="btn pri" type="submit">${esc(t('send'))}</button></form><div id="cloudNotice" class="cloud-message" role="status" hidden></div><div class="cloud-room-note">${esc(t('noAI'))}</div></div>`;
 $('cloudMessageInput').value=chatDraft;drawMessages(true);loadMessages();
}
function drawMessages(scroll=false){
 const list=$('cloudMessages');if(!list)return;
 const bottom=list.scrollHeight-list.scrollTop-list.clientHeight<80;
 const frag=document.createDocumentFragment();
 if(!messages.length){const p=document.createElement('div');p.className='cloud-empty';p.textContent=t(messagesLoaded?'empty':'loadingMessages');frag.append(p);}
 for(const msg of messages){
  const el=document.createElement('article');el.className='cloud-bubble'+(msg.user_id===user?.id?' own':'');
  const h=document.createElement('header'),name=document.createElement('strong'),time=document.createElement('time');
  name.textContent=msg.display_name+' · '+String(msg.user_id).slice(0,6);time.dateTime=msg.created_at;time.textContent=new Date(msg.created_at).toLocaleString(L(),{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'});h.append(name,time);
  if(msg.user_id===user?.id){const del=document.createElement('button');del.type='button';del.textContent=t('delete');del.dataset.cloud='delete';del.dataset.id=String(msg.id);h.append(del);}
  const text=document.createElement('div');text.className='body';text.textContent=msg.body;el.append(h,text);frag.append(el);
 }
 const oldTop=list.scrollTop;list.replaceChildren(frag);list.scrollTop=scroll||bottom?list.scrollHeight:oldTop;
}
let messageLoading=false;
async function loadMessages(older=false){
 if(!client||!user||!ready||messageLoading)return;messageLoading=true;const stamp=epoch;
 try {
  let q=client.from('zos_messages').select('id,user_id,display_name,body,created_at').order('id',{ascending:false}).limit(50);
  if(older&&messages.length)q=q.lt('id',messages[0].id);
  const {data,error}=await q;if(error)throw error;if(stamp!==epoch)return;
  const map=new Map(messages.map(m=>[String(m.id),m]));for(const m of data||[])map.set(String(m.id),m);
  messages=Array.from(map.values()).sort((a,b)=>Number(a.id)-Number(b.id)).slice(-1000);messagesLoaded=true;drawMessages();
 }catch{if(stamp===epoch)note(t('fetchFailed'),'error');}finally{messageLoading=false;}
}
function setBusy(v){loading=v;document.getElementById('main').inert=v;document.getElementById('side').inert=v;updateStatus();}
function hydrate(){store.quiet(()=>window.ZOSApp?.hydrate());updateStatus();}
async function handleSession(session,force=false){
 const next=session?.user||null;
 if(!force&&user?.id===next?.id&&(ready||loading))return;
 if(!next&&!user&&!force){updateStatus();return;}
 const stamp=++epoch;clearTimeout(timer);clearTimeout(retryTimer);if(channel){client.removeChannel(channel);channel=null;}
 user=next;ready=false;pending.clear();conflicts.clear();versions.clear();messages=[];messagesLoaded=false;chatDraft='';realtime=false;lastSaved=null;lastError='';profileName='';
 const ui={lang:store.get('lang',L()),theme:store.get('theme','dark')};store.replace(ui);hydrate();
 if(!user){setBusy(false);if(dialog.open)render();return;}
 setBusy(true);if(dialog.open)render();
 try{
  const {data,error}=await client.from('zos_user_state').select('key,value,version,updated_at').eq('user_id',user.id);
  if(error)throw error;if(stamp!==epoch)return;
  const values={...ui};for(const row of data||[]){if(store.keys.includes(row.key)){values[row.key]=row.value;versions.set(row.key,Number(row.version));if(!lastSaved||row.updated_at>lastSaved)lastSaved=row.updated_at;}}
  store.replace(values);hydrate();ready=true;
  const result=await client.from('zos_profiles').select('display_name').eq('user_id',user.id).maybeSingle();
  if(stamp!==epoch)return;
  profileName=result.data?.display_name||String(user.user_metadata?.display_name||('Studente-'+user.id.slice(0,6))).slice(0,40);
  channel=client.channel('zos-room-'+user.id).on('postgres_changes',{event:'*',schema:'public',table:'zos_messages'},payload=>{
   if(payload.eventType==='DELETE'&&payload.old?.id){messages=messages.filter(m=>String(m.id)!==String(payload.old.id));drawMessages();}
   else loadMessages();
  }).subscribe(s=>{realtime=s==='SUBSCRIBED';updateStatus();if(realtime)loadMessages();});
 }catch{if(stamp===epoch){lastError='dbFailed';ready=false;}}
 finally{if(stamp===epoch){setBusy(false);if(dialog.open)render();updateStatus();}}
}
function queue(key,value){if(!user||!ready)return;pending.set(key,{value:clone(value),serial:++serial});lastError='';clearTimeout(timer);timer=setTimeout(flush,600);updateStatus();}
window.addEventListener('zos:change',e=>queue(e.detail.key,e.detail.value));
async function flush(){
 if(flushTask)return flushTask;
 if(!client||!user||!ready||!pending.size)return;
 if(!navigator.onLine){lastError='offline';updateStatus();return;}
 const stamp=epoch;
 flushTask=(async()=>{
  try{
   for(const [key,item] of Array.from(pending.entries())){
    if(stamp!==epoch)return;if(conflicts.has(key))continue;
    const {data,error}=await client.rpc('zos_save_state',{p_key:key,p_value:item.value,p_expected_version:versions.get(key)||0});
    if(stamp!==epoch)return;if(error)throw error;
    const res=Array.isArray(data)?data[0]:data;if(!res)throw Error('empty response');
    if(!res.saved){conflicts.set(key,{version:Number(res.version),value:res.value});if(dialog.open&&tab==='account')render();continue;}
    versions.set(key,Number(res.version));lastSaved=res.updated_at;lastError='';
    if(pending.get(key)?.serial===item.serial)pending.delete(key);
   }
  }catch{if(stamp===epoch){lastError='dbFailed';clearTimeout(retryTimer);retryTimer=setTimeout(flush,30000);}}
 })();
 updateStatus();try{await flushTask;}finally{flushTask=null;updateStatus();if(!lastError&&pending.size>conflicts.size){clearTimeout(timer);timer=setTimeout(flush,600);}}
}
function resolveConflict(key,local){
 const conflict=conflicts.get(key);if(!conflict)return;versions.set(key,conflict.version);conflicts.delete(key);
 if(!local){pending.delete(key);store.quiet(()=>store.set(key,conflict.value));hydrate();}
 render();if(local)flush();
}
async function refresh(){await flush();if(pending.size){note(t('noSaveExit'),'error');return;}if(user)await handleSession({user},true);}
function exportData(){
 const payload={format:'zos-cloud-progress',version:1,exportedAt:new Date().toISOString(),data:window.ZOSApp.snapshot()};
 const url=URL.createObjectURL(new Blob([JSON.stringify(payload,null,2)],{type:'application/json'}));const a=document.createElement('a');a.href=url;a.download='zos-progressi.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),5000);
}
async function importData(obj){
 if(!user||!ready){note(t('importAccount'),'error');return;}
 const raw=obj?.format==='zos-cloud-progress'?obj.data:obj;
 if(!raw||typeof raw!=='object'||Array.isArray(raw)){note(t('badFile'),'error');return;}
 const data={};try{for(const key of store.keys)if(Object.hasOwn(raw,key))data[key]=window.ZOSApp.clean(key,raw[key]);}catch{note(t('badFile'),'error');return;}
 if(!Object.keys(data).length){note(t('badFile'),'error');return;}
 if(!confirm(t('importConfirm')))return;
 store.quiet(()=>{for(const [k,v]of Object.entries(data))store.set(k,v);});hydrate();for(const [k,v]of Object.entries(data))queue(k,v);note(t('imported'));await flush();
}
function uuid(){return crypto.randomUUID();}
async function sendMessage(form){
 if(!user||!ready){note(t('noAuth'),'error');return;}
 const input=form.elements.message,body=input.value.trim();if(!body||body.length>2000)return;
 if(clientDraft!==body||!clientId){clientId=uuid();clientDraft=body;}
 const button=form.querySelector('button');button.disabled=true;
 try{
  const {data,error}=await client.rpc('zos_send_message',{p_body:body,p_client_id:clientId});if(error)throw error;
  const row=Array.isArray(data)?data[0]:data;if(!row)throw Error('missing confirmation');
  const map=new Map(messages.map(m=>[String(m.id),m]));map.set(String(row.id),row);messages=Array.from(map.values()).sort((a,b)=>Number(a.id)-Number(b.id));messagesLoaded=true;
  if(input.value.trim()===body){input.value='';chatDraft='';clientDraft='';clientId=null;}drawMessages(true);note(t('sent'),'ok');
 }catch(e){note(t(String(e.message).includes('rate_limited')?'rate':'notSent'),'error');}finally{button.disabled=false;}
}
async function authSubmit(form){
 if(!client){note(t('authFailed'),'error');return;}
 const mode=authMode,data=new FormData(form),email=String(data.get('email')||''),password=String(data.get('password')||'');
 const button=form.querySelector('button');button.disabled=true;note(t('signing'));
 const redirect=location.origin+location.pathname;
 try{
  let res;
  if(mode==='signup'){if(password.length<12)throw Error('weak');res=await client.auth.signUp({email,password,options:{emailRedirectTo:redirect,data:{display_name:String(data.get('name')||'').trim()}}});}
  else if(mode==='reset')res=await client.auth.resetPasswordForEmail(email,{redirectTo:redirect});
  else res=await client.auth.signInWithPassword({email,password});
  if(res.error)throw res.error;
  if(mode==='reset')note(t('resetSent'),'ok');else if(mode==='signup'&&!res.data?.session)note(t('checkMail'),'ok');
  else if(res.data?.session)await handleSession(res.data.session);
 }catch(e){note(t(e.message==='weak'?'minPassword':'authFailed'),'error');}finally{button.disabled=false;}
}
document.addEventListener('click',async e=>{
 const b=e.target.closest('[data-cloud],#chatFab');if(!b)return;e.preventDefault();e.stopImmediatePropagation();
 const action=b.id==='chatFab'?'room':b.dataset.cloud;
 if(action==='close'){dialog.close();return;}
 if(action==='account'||action==='room'){open(action);return;}
 if(action==='guide'){dialog.close();window.ZOSApp.openAssistant();return;}
 if(action.startsWith('auth-')){authMode=action.slice(5);render();return;}
 if(action==='export'){exportData();return;}
 if(action==='refresh'||action==='retry'){await refresh();return;}
 if(action==='older'){loadMessages(true);return;}
 if(action==='remote'||action==='local'){resolveConflict(b.dataset.key,action==='local');return;}
 if(action==='legacy'){const old=store.legacy();if(!Object.keys(old).length)note(t('noLegacy'));else importData(old);return;}
 if(action==='import'){
  if(!user||!ready){note(t('importAccount'),'error');return;}
  const input=document.createElement('input');input.type='file';input.accept='.json,application/json';
  input.addEventListener('change',async()=>{const f=input.files[0];if(!f)return;if(f.size>2000000){note(t('badFile'),'error');return;}try{await importData(JSON.parse(await f.text()));}catch{note(t('badFile'),'error');}});input.click();return;
 }
 if(action==='delete'&&confirm(t('deleteConfirm'))){
  const {data,error}=await client.rpc('zos_delete_message',{p_id:b.dataset.id});if(error||!data){note(t('authFailed'),'error');return;}
  messages=messages.filter(m=>String(m.id)!==b.dataset.id);drawMessages();return;
 }
 if(action==='logout'){
  await flush();if(pending.size){note(t('noSaveExit'),'error');return;}
  const {error}=await client.auth.signOut();if(error)note(t('authFailed'),'error');else {recovery=false;await handleSession(null,true);}return;
 }
},true);
document.addEventListener('submit',async e=>{
 const f=e.target;if(!['cloudAuthForm','cloudMessageForm','cloudNameForm','cloudPasswordForm'].includes(f.id))return;e.preventDefault();e.stopImmediatePropagation();
 if(f.id==='cloudAuthForm'){await authSubmit(f);return;}
 if(f.id==='cloudMessageForm'){await sendMessage(f);return;}
 if(!client||!user)return;
 const button=f.querySelector('button');button.disabled=true;
 try{
  if(f.id==='cloudNameForm'){
   const {data,error}=await client.rpc('zos_set_name',{p_name:f.elements.name.value.trim()});if(error)throw error;profileName=data;note(t('nameSaved'),'ok');
  }else{
   const {error}=await client.auth.updateUser({password:f.elements.password.value});if(error)throw error;recovery=false;render();note(t('passwordUpdated'),'ok');
  }
 }catch{note(t('authFailed'),'error');}finally{button.disabled=false;}
},true);
document.addEventListener('input',e=>{if(e.target.id==='cloudMessageInput')chatDraft=e.target.value;});
window.addEventListener('online',()=>{flush();loadMessages();updateStatus();});
window.addEventListener('offline',updateStatus);
window.addEventListener('beforeunload',e=>{if(pending.size){e.preventDefault();e.returnValue='';}});
document.addEventListener('visibilitychange',()=>{if(document.hidden)flush();else if(user){loadMessages();updateStatus();}});
setInterval(()=>{if(user&&ready&&dialog.open&&tab==='room'&&!document.hidden)loadMessages();},15000);
window.ZOSOnline={
 open,
 refreshLabels(){updateStatus();},
 sidebarHTML(){return `<h6>CLOUD</h6><a href="#" data-cloud="account"><span class="n">☁</span><span data-cloud-label="account">${esc(t('account'))}</span></a><a href="#" data-cloud="room"><span class="n">↗</span><span data-cloud-label="room">${esc(t('room'))}</span></a>`;},
 async request(r,language){
  if(!user||!ready){open('account');throw Error(t('noAuth'));}
  const {data,error}=await client.rpc('zos_submit_request',{p_kind:r.kind,p_body:r.msg,p_lang:language});
  if(error)throw Error(t(String(error.message).includes('rate_limited')?'rate':'authFailed'));
  return t('requestSaved')+' (#'+data+')';
 },
 // Observable non-secret state for smoke tests and support. No tokens or email.
 diagnostics(){return {configured:configValid,ready,status:status(),pending:pending.size,conflicts:conflicts.size,realtime};}
};
window.ZOSApp?.hydrate();updateStatus();
async function start(){
 try{
  client=window.supabase.createClient(C.supabaseUrl,C.publishableKey,{auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:true,storageKey:'zos-cloud-auth'}});
  client.auth.onAuthStateChange((event,session)=>{setTimeout(()=>{if(event==='PASSWORD_RECOVERY'){recovery=true;open('account');}handleSession(session);},0);});
  const {data,error}=await client.auth.getSession();if(error)throw error;await handleSession(data.session);
 }catch{lastError='authFailed';updateStatus();}
}
if(configValid){
 if(window.supabase?.createClient)start();
 else{
  const sdk=document.createElement('script');sdk.src=C.sdkPath||'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.102.0';sdk.crossOrigin='anonymous';sdk.onload=start;
  sdk.onerror=()=>{lastError='authFailed';updateStatus();if(dialog.open)note(t('authFailed'),'error');};document.head.append(sdk);
 }
}
})();
