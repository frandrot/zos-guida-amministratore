# Database reale: verifica del 7 ottobre 2026

Progetto: `rdmogdsycnxqwdyrnygw` (zos).

1. PASS — Authenticated progress save.
2. PASS — Stale-device overwrite rejected.
3. PASS — Message persistence and retry deduplication.
4. PASS — Content request saved.
5. PASS — Second account cannot read private progress or requests.
6. PASS — Member can read chat but cannot delete another member message.
7. PASS — Direct table writes denied.
8. PASS — Message deletion does not reset anti-spam rate limit.
9. PASS — Anonymous Auth sessions denied.
10. PASS — Unauthenticated role denied chat reads and write RPCs.
11. PASS — All test accounts and data rolled back.

Test SQL con ruoli anon/authenticated e claim JWT emulati. Dati creati solo in una subtransazione annullata, senza invio email e senza account di prova permanenti.
Non e un collaudo HTTP/browser/Auth/Realtime end-to-end.

Controllo Supabase Security Advisors finale: nessun avviso restituito (`lints: []`).
