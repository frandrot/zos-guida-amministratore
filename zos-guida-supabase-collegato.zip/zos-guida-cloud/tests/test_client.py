"""Browser integration tests with a controlled in-memory backend.
These DO NOT connect to Supabase or prove a deployed RLS/WebSocket setup.
No browser navigation/network access is required.
"""
from pathlib import Path
from datetime import datetime,timezone
import re,json,os,shutil
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]/'public'
uidA='11111111-1111-4111-8111-111111111111';uidB='22222222-2222-4222-8222-222222222222'
DB={'state':{},'messages':[],'profiles':{},'fail':False};reports=[]
def now():return datetime.now(timezone.utc).isoformat()
def call(req):
 uid=req.get('uid');name=req['name'];a=req.get('args',{})
 if req['type']=='query':
  if name=='zos_user_state':data=list(DB['state'].get(uid,{}).values())
  elif name=='zos_profiles':data=[{'display_name':DB['profiles'][uid]}] if uid in DB['profiles'] else []
  elif name=='zos_messages':
   data=sorted(DB['messages'],key=lambda r:r['id'],reverse=True)
   if a.get('lt'):data=[r for r in data if r['id']<int(a['lt'][1])]
   data=data[:50]
  else:data=[]
  if a.get('single'):data=data[0] if data else None
  return {'data':data,'error':None}
 if not uid:return {'data':None,'error':{'message':'not_authenticated'}}
 if name=='zos_save_state':
  if DB['fail']:return {'data':None,'error':{'message':'Network unavailable (simulated)'}}
  state=DB['state'].setdefault(uid,{});old=state.get(a['p_key']);ver=old['version'] if old else 0
  if a['p_expected_version']!=ver:return {'data':[dict(saved=False,version=ver,value=old['value'] if old else None,updated_at=now())],'error':None}
  state[a['p_key']]={'key':a['p_key'],'value':a['p_value'],'version':ver+1,'updated_at':now()}
  return {'data':[dict(saved=True,**state[a['p_key']])],'error':None}
 if name=='zos_send_message':
  for m in DB['messages']:
   if m['user_id']==uid and m['client_id']==a['p_client_id']:return {'data':[m],'error':None}
  m={'id':len(DB['messages'])+1,'user_id':uid,'client_id':a['p_client_id'],'display_name':DB['profiles'].get(uid,'Studente-'+uid[:6]),'body':a['p_body'],'created_at':now()};DB['messages'].append(m)
  return {'data':[m],'error':None}
 if name=='zos_delete_message':
  before=len(DB['messages']);DB['messages'][:]=[m for m in DB['messages'] if not(m['user_id']==uid and m['id']==int(a['p_id']))]
  return {'data':len(DB['messages'])<before,'error':None}
 if name=='zos_set_name':DB['profiles'][uid]=a['p_name'];return {'data':a['p_name'],'error':None}
 return {'data':1,'error':None}
base=(ROOT/'index.html').read_text().replace('<link rel="stylesheet" href="./cloud.css">','<style>'+(ROOT/'cloud.css').read_text()+'</style>')
base=re.sub(r'<script src="\./([^\"]+)"></script>',lambda m:'<script>'+(ROOT/m.group(1)).read_text()+'</script>',base)
base=base.replace((ROOT/'config.js').read_text(),"window.ZOS_CLOUD_CONFIG={supabaseUrl:'https://testproject.supabase.co',publishableKey:'sb_publishable_testkey',allowRegistration:true};")
mock=r'''const mem={};const memoryStorage={getItem:k=>mem[k]??null,setItem:(k,v)=>{mem[k]=String(v)},removeItem:k=>{delete mem[k]},clear:()=>{for(const k of Object.keys(mem))delete mem[k]}};Object.defineProperty(window,'localStorage',{value:memoryStorage});
if(!crypto.randomUUID)crypto.randomUUID=()=>{const b=crypto.getRandomValues(new Uint8Array(16));return Array.from(b,(n,i)=>n.toString(16).padStart(2,'0')).join('').replace(/^(.{8})(.{4})(.{4})(.{4})(.{12})$/,'$1-$2-$3-$4-$5')};
let current=INITIAL_USER,authCB=()=>{};const userFor=id=>id?{id,email:id.startsWith('1')?'alice@example.test':'bob@example.test',user_metadata:{display_name:id.startsWith('1')?'Alice':'Bob'}}:null;
const invoke=(type,name,args)=>window.__backend({type,name,args,uid:current});
window.supabase={createClient:()=>({
 auth:{getSession:async()=>({data:{session:current?{user:userFor(current)}:null},error:null}),onAuthStateChange:cb=>{authCB=cb;return {data:{subscription:{unsubscribe(){}}}}},signInWithPassword:async({email})=>{current=email.startsWith('alice')?'11111111-1111-4111-8111-111111111111':'22222222-2222-4222-8222-222222222222';const session={user:userFor(current)};setTimeout(()=>authCB('SIGNED_IN',session),0);return {data:{session},error:null}},signOut:async()=>{current=null;setTimeout(()=>authCB('SIGNED_OUT',null),0);return {error:null}},resetPasswordForEmail:async()=>({error:null}),updateUser:async()=>({error:null})},
 from(name){let args={};return {select(){return this},eq(k,v){args.eq=[k,v];return this},order(){return this},limit(){return this},lt(k,v){args.lt=[k,v];return this},maybeSingle(){args.single=true;return this},then(resolve,reject){return invoke('query',name,args).then(resolve,reject)}}},
 rpc:(name,args)=>invoke('rpc',name,args),
 channel:()=>({on(event,filters,cb){window.__realtimeCB=cb;return this},subscribe(cb){setTimeout(()=>cb('SUBSCRIBED'),0);return this}}),removeChannel:async()=>{}
})};'''
errors=[]
def check(name,result):
 assert result,name
 reports.append(name);print('PASS',name,flush=True)
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True, executable_path=os.environ.get('BROWSER_EXECUTABLE') or shutil.which('chromium') or None)
 def page_for(uid=None,mobile=False):
  ctx=browser.new_context(locale='it-IT',viewport={'width':390,'height':844} if mobile else {'width':1440,'height':1000})
  page=ctx.new_page();page.on('pageerror',lambda e:errors.append(str(e)));page.expose_function('__backend',call)
  html=base.replace('<head>','<head><script>'+mock.replace('INITIAL_USER',json.dumps(uid))+'</script>')
  page.set_content(html);page.wait_for_timeout(300)
  if uid:page.wait_for_function('ZOSOnline.diagnostics().ready')
  return page
 def saved(page):page.wait_for_function('ZOSOnline.diagnostics().pending===0 && ZOSOnline.diagnostics().status==="saved"',timeout=6000)
 a=page_for();a.locator('#cloudAccount').click();a.locator('#cloudAuthForm input[name=email]').fill('alice@example.test');a.locator('#cloudAuthForm input[name=password]').fill('test-password-123');a.locator('#cloudAuthForm button').click();a.wait_for_function('ZOSOnline.diagnostics().ready');a.locator('[data-cloud=close]').click();check('login hydrates authenticated account',a.evaluate('ZOSOnline.diagnostics().ready'))
 a.locator('[data-done=intro]').click();a.locator('#quizChoice0').check();a.locator('[data-q=verify]').click();
 a.locator('#labInput').fill('PROFILE');a.locator('#labRun').click();saved(a)
 check('module, quiz and console sent to backend',all(k in DB['state'][uidA] for k in ['done','quiz-state','lab-v1']))
 check('no progress saved to browser storage',a.evaluate('Object.keys(mem).every(k=>k.startsWith("zoscloud:ui:"))'))
 a2=page_for(uidA);check('new device restores module progress','intro' in a2.evaluate('ZOSStore.get("done",[])'))
 check('new device restores unfinished quiz',a2.evaluate('ZOSStore.get("quiz-state",{}).ans')==0)
 check('new device restores console history','PROFILE' in a2.evaluate('ZOSStore.get("lab-v1",{}).history'))
 b=page_for(uidB);check('different user starts with separate progress',b.evaluate('ZOSStore.get("done",[])')==[])
 a.locator('#chatFab').click();a.locator('#cloudMessageInput').fill('Ciao dal test, storico sul server.');a.locator('#cloudMessageForm button').click();a.wait_for_function('document.getElementById("cloudMessageInput").value===""')
 b.locator('#chatFab').click();b.wait_for_function('document.getElementById("cloudMessages").textContent.includes("Ciao dal test")');check('second user loads shared stored chat',True)
 b.locator('#cloudMessageInput').fill('<img src=x onerror="window.__xss=1">');b.locator('#cloudMessageForm button').click();b.wait_for_function('document.getElementById("cloudMessageInput").value===""');check('message HTML is displayed as text',not b.evaluate('!!window.__xss') and b.locator('#cloudMessages img').count()==0)
 a.locator('[data-cloud=close]').click();a.locator('[data-done=access]').click();saved(a)
 a2.locator('[data-done=datasets]').click();a2.wait_for_function('ZOSOnline.diagnostics().conflicts===1',timeout=6000)
 check('stale second device cannot silently overwrite',DB['state'][uidA]['done']['value']==['intro','access'])
 a2.locator('#cloudAccount').click();a2.locator('[data-cloud=remote]').click();check('explicit conflict resolution loads server version',a2.evaluate('ZOSStore.get("done",[])')==['intro','access'])
 DB['fail']=True;a.evaluate('ZOSStore.set("theme","light")');a.wait_for_function('ZOSOnline.diagnostics().status==="error"',timeout=6000)
 check('failed backend save is not reported saved',a.evaluate('ZOSOnline.diagnostics().pending')>0)
 DB['fail']=False;a.locator('#cloudAccount').click();a.locator('[data-cloud=refresh]').click();a.wait_for_function('ZOSOnline.diagnostics().ready && ZOSOnline.diagnostics().pending===0');check('retry confirms pending writes',DB['state'][uidA]['theme']['value']=='light')
 a.locator('[data-cloud=logout]').click();a.wait_for_function('!ZOSOnline.diagnostics().ready');check('logout clears user progress from active page',a.evaluate('ZOSStore.get("done",[])')==[])
 mobile=page_for(uidB,True);mobile.locator('#chatFab').click();mobile.wait_for_timeout(200);check('mobile dialog and page fit viewport',not mobile.evaluate('document.documentElement.scrollWidth>innerWidth') and not mobile.locator('#cloudDialog').evaluate('(e)=>e.scrollWidth>e.clientWidth'))
 check('no browser JavaScript exceptions',not errors)
 browser.close()
Path(__file__).resolve().with_name('results.json').write_text(json.dumps({'tests':reports,'count':len(reports),'errors':errors,'backend':'controlled mock; no live Supabase/GitHub test'},indent=2))
