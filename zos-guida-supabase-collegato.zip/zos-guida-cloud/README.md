# z/OS dalla A alla Z · Cloud

Guida originale con console simulata, 12 esercizi guidati, quiz a scelta multipla e mascotte, estesa con account personali, database e chat condivisa. Italiano, spagnolo e inglese sono mantenuti.

**Stato aggiornato:** backend Supabase `zos` configurato e verificato. Client gia collegato con chiave pubblicabile. Il sito NON e ancora pubblicato su GitHub. Leggi `STATO-PUBBLICAZIONE.md` per quanto completato e per i passaggi ancora necessari.

## Architettura

GitHub conserva e versiona il codice. GitHub Pages ospita il sito statico. Supabase gestisce autenticazione, database PostgreSQL e aggiornamenti della chat. Pubblicare il solo HTML su GitHub **non** rende persistenti i dati del browser: occorre completare anche il collegamento al database.

La console **rimane un simulatore didattico** nel browser. I comandi non vengono eseguiti su IBM z/OS; il server conserva lo stato della simulazione e i progressi.

## 1. Database (gia configurato su questo progetto)

Per questo pacchetto il progetto `zos` e gia stato configurato. Le istruzioni seguenti servono solo per una nuova installazione su un altro progetto autorizzato. Nessun piano a pagamento è necessario al codice; disponibilità, limiti, conservazione e costi dipendono dal piano scelto. Per i dati personali scegli la regione appropriata, ad esempio una regione UE per il tuo pubblico italiano.

Verifica che la Data API sia abilitata ed esponga lo schema `public` e gli oggetti `zos_` utilizzati. Apri **SQL Editor** del progetto ed esegui `supabase/setup.sql`. Lo script crea solamente tabelle e funzioni con prefisso `zos_`, abilita la sicurezza a livello di riga e aggiunge la chat alla pubblicazione Realtime senza rimuovere le tabelle già presenti. Prima di eseguirlo su un database già in uso, controlla che non esistano oggetti omonimi creati da un altro progetto.

Le tabelle principali sono:

| Tabella | Contenuto | Accesso dall’app |
| --- | --- | --- |
| `zos_user_state` | Progressi, quiz, console, preferenze e cronologia dell’assistente | Solo il proprietario autenticato |
| `zos_profiles` | Nome pubblico nella chat, non email o password | Utenti autenticati |
| `zos_messages` | Messaggi della stanza condivisa | Utenti autenticati; cancellazione solo dei propri |
| `zos_content_requests` | Richieste di nuovi contenuti | Solo il mittente; amministrazione dal pannello Supabase |

Le scritture passano da funzioni che ricavano l’identità dalla sessione, non da un ID scelto nel browser. Gli utenti non possono scrivere direttamente nelle tabelle. Le nuove richieste vengono conservate nel database; **non** inviano automaticamente email al team.

## 2. Pubblicare su GitHub

### Dal sito GitHub

Crea un repository con il nome desiderato, ad esempio `zos-guida-amministratore`, e carica **il contenuto completo della cartella del progetto**, non solo `public/index.html`. Conserva anche `.github/workflows/pages.yml`.

Scegli consapevolmente se il codice deve essere pubblico o privato. GitHub Pages su GitHub Free richiede un repository pubblico; per repository privati occorre un piano che supporti Pages. Il sito pubblicato può comunque essere pubblico anche se il codice del repository è privato. Non rendere pubblico un repository esistente per aggirare questa scelta.

In **Settings → Pages → Build and deployment → Source**, scegli **GitHub Actions**.

Il preset `cloud-public.json` contiene gia URL e chiave pubblicabile. In **Settings → Secrets and variables → Actions → Variables**, imposta `ZOS_DEPLOY_ENABLED=true`. Le altre due variabili della tabella sono opzionali e sovrascrivono il preset:

| Variabile | Valore |
| --- | --- |
| `SUPABASE_URL` | URL HTTPS del progetto Supabase |
| `SUPABASE_PUBLISHABLE_KEY` | Chiave `sb_publishable_...`, oppure chiave legacy `anon` |
| `ZOS_DEPLOY_ENABLED` | `true` |

Questi sono parametri pubblici del client, non password. **Non usare** la password del database, una chiave `sb_secret_...` o `service_role`. La chiave pubblica non sostituisce le regole RLS: lo schema SQL deve essere applicato.

Apri **Actions → Pubblica guida zOS → Run workflow**. Il workflow genera la configurazione pubblica, verifica la sintassi JavaScript e pubblica **soltanto** la cartella `public`. Gli aggiornamenti successivi sul ramo `main` attivano una nuova pubblicazione. Finché `ZOS_DEPLOY_ENABLED` non è `true`, il job viene saltato intenzionalmente.

Attendi il risultato del workflow; avviarlo non equivale a completare la pubblicazione. Recupera l’indirizzo reale da **Settings → Pages → Visit site**. Non è stato inventato o prenotato un URL per questo pacchetto.

### Alternativa Windows: script assistito

È incluso `scripts/PUBBLICA_GITHUB.ps1`. Richiede Git e GitHub CLI ufficiale già installati. Lo script apre l’accesso a GitHub nel browser, legge l’account autenticato e chiede una conferma prima di creare e caricare un nuovo repository. Non sovrascrive repository esistenti, non forza push e non acquista piani.

Da PowerShell, nella cartella estratta:

```powershell
# Repository privato (impostazione prudente predefinita).
.\scripts\PUBBLICA_GITHUB.ps1

# Solo dopo aver deciso esplicitamente di rendere pubblico il codice:
.\scripts\PUBBLICA_GITHUB.ps1 -Visibility public
```

Se Windows applica restrizioni agli script, usa la procedura dal sito GitHub o chiedi all’amministratore di autorizzare lo script; non occorre disattivare le protezioni del computer. L’autenticazione GitHub deve consentire la creazione del repository, l’invio dei workflow e la gestione di Pages/variabili. Lo script è fornito, ma **non è stato eseguito** in questa consegna.

## 3. Completare l’accesso utenti

In Supabase **Authentication → URL Configuration**, imposta come **Site URL** l’indirizzo reale appena pubblicato, inclusa la sottocartella del progetto. Aggiungilo anche alle **Redirect URLs**, nelle forme effettivamente utilizzate, per esempio con e senza `index.html`. Non usare wildcard ampie senza necessità.

Abilita email e password, mantieni la conferma dell’email e configura un servizio SMTP adatto all’uso reale. Il servizio email predefinito di Supabase è limitato e non va considerato un sistema di invio di produzione. Verifica registrazione, conferma e recupero password con indirizzi autorizzati prima di invitare il gruppo.

La registrazione è visibile per impostazione predefinita. **Tutti gli utenti registrati possono leggere la stanza condivisa.** Per un gruppo ristretto, disabilita le nuove registrazioni in Supabase Auth e invita solo gli utenti autorizzati. Nascondere il pulsante con `allowRegistration: false` è solo una scelta d’interfaccia, non un controllo d’accesso. Per una pubblicazione aperta al pubblico aggiungi CAPTCHA, politiche di moderazione, gestione abusi e informative adeguate prima del lancio.

## Come funziona il salvataggio

Moduli, quiz anche non terminati, generatore JCL, laboratorio con dataset simulati e cronologia comandi, e cronologia della ricerca nella guida vengono caricati dall’account all’accesso. Ogni dato ha una versione: una scheda vecchia non può sovrascrivere silenziosamente una modifica più recente dello stesso dato. In caso di conflitto l’utente sceglie quale versione mantenere.

Un altro dispositivo recupera i dati accedendo allo stesso account. In una scheda già aperta, **Ricarica dal server** recupera gli aggiornamenti salvati altrove; i progressi non sono sincronizzati in streaming mentre si sta scrivendo. La chat usa Realtime e ricarica periodicamente lo storico come recupero in caso di disconnessione.

**“Salvato sul server”** richiede una risposta positiva del database. Durante un errore o una disconnessione le modifiche non confermate restano in memoria nella scheda e viene mostrato un avviso; chiudere la scheda o un arresto del browser prima della conferma può perderle. Non è un sistema offline con coda persistente.

La sessione di accesso e le preferenze di visualizzazione possono usare lo storage del browser. I dati di studio degli utenti autenticati non sono affidati al solo `localStorage`. Senza login si può consultare e provare la guida, ma i progressi di quella sessione non sono salvati online.

Sono disponibili esportazione e importazione JSON dei progressi. L’importazione richiede conferma e sovrascrive solo i campi presenti nel file. L’importazione dei dati della vecchia guida dal browser funziona soltanto quando essi sono accessibili dallo **stesso indirizzo/origine**. Il nuovo sito non può leggere la memoria di un vecchio file HTML locale o di un altro dominio. Esporta prima di cambiare contesto o di accedere dopo una prova senza account.

Conservazione dei dati non significa conservazione illimitata: cancellare il progetto Supabase o un account elimina i dati relativi. Prevedi backup e verifica delle procedure di ripristino secondo il piano e le esigenze del progetto. Nessun backup esterno o job di manutenzione è stato configurato in questa consegna.

## Chat e assistente: due funzioni distinte

**Chat online** è una stanza tra persone, con messaggi memorizzati e caricamento dello storico. Mostra solo ciò che il server restituisce, non risposte inventate. I contenuti HTML vengono mostrati come testo. Il client può cancellare solo i messaggi dell’utente collegato.

**Cerca nella guida** conserva la ricerca automatica tra i contenuti del file originale. Non è un modello AI e non si collega a un servizio AI. L’invio di richieste di contenuti viene associato all’account e conservato nel database, non simulato con gli appunti.

## Dipendenze e verifica prima del lancio

Il workflow scarica da jsDelivr il client Supabase JavaScript nella versione fissata `2.102.0` e pubblica la copia in `public/vendor/`: sul sito generato dal workflow la libreria viene servita dallo stesso sito. Se il download fallisce, la pubblicazione si interrompe. Per una prova dei sorgenti con configurazione manuale è previsto il caricamento CDN. La libreria non è inclusa nel pacchetto sorgente e il download dalla rete non è stato verificato in questa sessione. Verifica la riuscita del workflow e l’avvio del client prima di distribuire il sito.

Prima di distribuire il sito, prova su servizi reali: accesso di due utenti distinti; isolamento dei progressi; salvataggio e recupero dopo chiusura del browser; invio, lettura e cancellazione dei messaggi; permessi anonimi; email di conferma e recupero; aggiornamenti Realtime; conflitto tra due schede; mancata connessione e ripresa; navigazione mobile.

`tests/REPORT.md` descrive i test effettivamente eseguiti. I test con backend simulato verificano la logica del client, **non** certificano SQL, RLS, email o WebSocket di un progetto Supabase reale.

## Fonti ufficiali

- GitHub Pages: https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site
- Workflow Pages: https://docs.github.com/en/pages/getting-started-with-github-pages/using-custom-workflows-with-github-pages
- GitHub CLI: https://cli.github.com/manual/gh_repo_create
- API GitHub Pages: https://docs.github.com/en/rest/pages/pages
- Supabase Auth: https://supabase.com/docs/guides/auth/passwords
- Chiavi pubbliche e segrete: https://supabase.com/docs/guides/getting-started/api-keys
- RLS: https://supabase.com/docs/guides/database/postgres/row-level-security
- Realtime: https://supabase.com/docs/guides/realtime/subscribing-to-database-changes
