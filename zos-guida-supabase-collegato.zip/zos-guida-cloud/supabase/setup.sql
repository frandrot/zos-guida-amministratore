-- z/OS Guida · schema cloud v3 · verified Supabase connection
-- Run once in the SQL editor of the selected Supabase project (postgres role).
-- Idempotent. No existing tables, users, publications or data are dropped.
begin;
create schema if not exists zos_private;
revoke all on schema zos_private from public,anon,authenticated;
grant usage on schema public,zos_private to authenticated;

create table if not exists public.zos_user_state (
  user_id uuid not null references auth.users(id) on delete cascade,
  key text not null check (key in ('lang','theme','done','best','builder','lab-v1','quiz-state','chat','masMuted','masSeen')),
  value jsonb not null check (octet_length(value::text) <= 524288),
  version bigint not null default 1 check (version > 0),
  updated_at timestamptz not null default now(),
  primary key (user_id,key)
);
create table if not exists public.zos_profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null check (char_length(btrim(display_name)) between 2 and 40),
  updated_at timestamptz not null default now()
);
create table if not exists public.zos_messages (
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  client_id uuid not null,
  display_name text not null,
  body text not null check (char_length(btrim(body)) between 1 and 2000),
  created_at timestamptz not null default now(),
  unique (user_id,client_id)
);
create index if not exists zos_messages_user_time on public.zos_messages(user_id,created_at desc);
create table if not exists public.zos_content_requests (
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  kind text not null check (kind in ('new','fix','other')),
  body text not null check (char_length(btrim(body)) between 1 and 4000),
  lang text not null check (lang in ('it','es','en')),
  created_at timestamptz not null default now()
);
create index if not exists zos_requests_user_time on public.zos_content_requests(user_id,created_at desc);

alter table public.zos_user_state enable row level security;
alter table public.zos_profiles enable row level security;
alter table public.zos_messages enable row level security;
alter table public.zos_content_requests enable row level security;
revoke all on public.zos_user_state, public.zos_profiles, public.zos_messages, public.zos_content_requests from public,anon,authenticated;
grant select on public.zos_user_state, public.zos_profiles, public.zos_messages, public.zos_content_requests to authenticated;
-- Progress and requests are PRIVATE. Chat messages/nicknames are shared ONLY
-- with authenticated members. Emails stay in auth.users, not in public tables.
do $$ begin
 if not exists (select 1 from pg_policies where schemaname='public' and tablename='zos_user_state' and policyname='zos_own_state') then
  create policy zos_own_state on public.zos_user_state for select to authenticated using ((select auth.uid())=user_id and coalesce((select auth.jwt()->>'is_anonymous'),'false')='false');
 end if;
 if not exists (select 1 from pg_policies where schemaname='public' and tablename='zos_profiles' and policyname='zos_member_profiles') then
  create policy zos_member_profiles on public.zos_profiles for select to authenticated using ((select auth.uid()) is not null and coalesce((select auth.jwt()->>'is_anonymous'),'false')='false');
 end if;
 if not exists (select 1 from pg_policies where schemaname='public' and tablename='zos_messages' and policyname='zos_member_messages') then
  create policy zos_member_messages on public.zos_messages for select to authenticated using ((select auth.uid()) is not null and coalesce((select auth.jwt()->>'is_anonymous'),'false')='false');
 end if;
 if not exists (select 1 from pg_policies where schemaname='public' and tablename='zos_content_requests' and policyname='zos_own_requests') then
  create policy zos_own_requests on public.zos_content_requests for select to authenticated using ((select auth.uid())=user_id and coalesce((select auth.jwt()->>'is_anonymous'),'false')='false');
 end if;
end $$;


-- Internal counters cannot be reset by deleting chat messages.
create table if not exists zos_private.zos_rate_limits (
 user_id uuid not null references auth.users(id) on delete cascade,
 action text not null check(action in ('message','request')),
 window_started_at timestamptz not null,
 used integer not null check(used>0),
 primary key(user_id,action)
);
alter table zos_private.zos_rate_limits enable row level security;
revoke all on zos_private.zos_rate_limits from public,anon,authenticated;
do $$ begin
 if not exists(select 1 from pg_policies where schemaname='zos_private' and tablename='zos_rate_limits' and policyname='zos_no_direct_rate_access') then
  create policy zos_no_direct_rate_access on zos_private.zos_rate_limits as restrictive for all to anon,authenticated using(false) with check(false);
 end if;
end $$;
create or replace function zos_private.zos_consume_rate(p_action text)
returns void language plpgsql security definer set search_path='' as $$
declare uid uuid:=auth.uid(); ts timestamptz:=clock_timestamp(); span interval; cap integer; n integer;
begin
 if uid is null or coalesce((auth.jwt()->>'is_anonymous')::boolean,false) then raise exception 'not_authenticated'; end if;
 if p_action='message' then span:=interval '1 minute'; cap:=10;
 elsif p_action='request' then span:=interval '1 hour'; cap:=5;
 else raise exception 'invalid_action'; end if;
 insert into zos_private.zos_rate_limits as r(user_id,action,window_started_at,used) values(uid,p_action,ts,1)
 on conflict(user_id,action) do update set
 window_started_at=case when r.window_started_at <= ts-span then ts else r.window_started_at end,
 used=case when r.window_started_at <= ts-span then 1 else r.used+1 end
 returning used into n;
 if n>cap then raise exception 'rate_limited'; end if;
end $$;
revoke all on function zos_private.zos_consume_rate(text) from public,anon,authenticated;

-- Atomic compare-and-swap: a stale browser cannot silently overwrite a newer
-- version from a second device. user_id is obtained from the verified JWT.
create or replace function zos_private.zos_save_state(p_key text,p_value jsonb,p_expected_version bigint)
returns table(saved boolean,version bigint,value jsonb,updated_at timestamptz)
language plpgsql security definer set search_path='' as $$
declare uid uuid := auth.uid(); rec public.zos_user_state%rowtype;
begin
 if uid is null or coalesce((auth.jwt()->>'is_anonymous')::boolean,false) then raise exception 'not_authenticated'; end if;
 if p_expected_version is null or p_expected_version < 0 or p_value is null then raise exception 'invalid_state'; end if;
 if p_expected_version=0 then
  insert into public.zos_user_state(user_id,key,value) values(uid,p_key,p_value)
  on conflict (user_id,key) do nothing returning * into rec;
 else
  update public.zos_user_state as s set value=p_value, version=s.version+1, updated_at=clock_timestamp()
   where s.user_id=uid and s.key=p_key and s.version=p_expected_version returning s.* into rec;
 end if;
 if found then return query select true,rec.version,rec.value,rec.updated_at; return; end if;
 select s.* into rec from public.zos_user_state s where s.user_id=uid and s.key=p_key;
 return query select false,coalesce(rec.version,0),coalesce(rec.value,'null'::jsonb),rec.updated_at;
end $$;

create or replace function zos_private.zos_set_name(p_name text)
returns text language plpgsql security definer set search_path='' as $$
declare uid uuid:=auth.uid(); n text:=btrim(p_name);
begin
 if uid is null or coalesce((auth.jwt()->>'is_anonymous')::boolean,false) then raise exception 'not_authenticated'; end if;
 if n is null or char_length(n) not between 2 and 40 or n ~ '[[:cntrl:]]' then raise exception 'invalid_name'; end if;
 insert into public.zos_profiles(user_id,display_name) values(uid,n)
 on conflict(user_id) do update set display_name=excluded.display_name,updated_at=clock_timestamp();
 return n;
end $$;

create or replace function zos_private.zos_send_message(p_body text,p_client_id uuid)
returns setof public.zos_messages language plpgsql security definer set search_path='' as $$
declare uid uuid:=auth.uid(); n text; previous public.zos_messages%rowtype;
begin
 if uid is null or coalesce((auth.jwt()->>'is_anonymous')::boolean,false) then raise exception 'not_authenticated'; end if;
 if p_client_id is null or p_body is null or char_length(btrim(p_body)) not between 1 and 2000 then raise exception 'invalid_message'; end if;
 perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended(uid::text, 1701));
 select m.* into previous from public.zos_messages m where m.user_id=uid and m.client_id=p_client_id;
 if found then return next previous; return; end if;
 perform zos_private.zos_consume_rate('message');
 select display_name into n from public.zos_profiles where user_id=uid;
 if n is null then n:='Studente-'||left(uid::text,6); end if;
 return query insert into public.zos_messages(user_id,client_id,display_name,body)
  values(uid,p_client_id,n,btrim(p_body)) returning *;
end $$;

create or replace function zos_private.zos_delete_message(p_id bigint)
returns boolean language plpgsql security definer set search_path='' as $$
begin
 if auth.uid() is null or coalesce((auth.jwt()->>'is_anonymous')::boolean,false) then raise exception 'not_authenticated'; end if;
 delete from public.zos_messages where id=p_id and user_id=auth.uid();
 return found;
end $$;

create or replace function zos_private.zos_submit_request(p_kind text,p_body text,p_lang text)
returns bigint language plpgsql security definer set search_path='' as $$
declare uid uuid:=auth.uid(); rid bigint;
begin
 if uid is null or coalesce((auth.jwt()->>'is_anonymous')::boolean,false) then raise exception 'not_authenticated'; end if;
 perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended(uid::text,1702));
 perform zos_private.zos_consume_rate('request');
 insert into public.zos_content_requests(user_id,kind,body,lang) values(uid,p_kind,btrim(p_body),p_lang) returning id into rid;
 return rid;
end $$;

-- Public RPCs do not have elevated privileges. Private routines validate the JWT.
create or replace function public.zos_save_state(p_key text,p_value jsonb,p_expected_version bigint)
returns table(saved boolean,version bigint,value jsonb,updated_at timestamptz) language sql security invoker set search_path='' as $$ select * from zos_private.zos_save_state(p_key,p_value,p_expected_version); $$;
create or replace function public.zos_set_name(p_name text)
returns text language sql security invoker set search_path='' as $$ select zos_private.zos_set_name(p_name); $$;
create or replace function public.zos_send_message(p_body text,p_client_id uuid)
returns setof public.zos_messages language sql security invoker set search_path='' as $$ select * from zos_private.zos_send_message(p_body,p_client_id); $$;
create or replace function public.zos_delete_message(p_id bigint)
returns boolean language sql security invoker set search_path='' as $$ select zos_private.zos_delete_message(p_id); $$;
create or replace function public.zos_submit_request(p_kind text,p_body text,p_lang text)
returns bigint language sql security invoker set search_path='' as $$ select zos_private.zos_submit_request(p_kind,p_body,p_lang); $$;
revoke all on function public.zos_save_state(text,jsonb,bigint),public.zos_set_name(text),public.zos_send_message(text,uuid),public.zos_delete_message(bigint),public.zos_submit_request(text,text,text) from public,anon,authenticated;
grant execute on function public.zos_save_state(text,jsonb,bigint),public.zos_set_name(text),public.zos_send_message(text,uuid),public.zos_delete_message(bigint),public.zos_submit_request(text,text,text) to authenticated;
revoke all on function zos_private.zos_save_state(text,jsonb,bigint),zos_private.zos_set_name(text),zos_private.zos_send_message(text,uuid),zos_private.zos_delete_message(bigint),zos_private.zos_submit_request(text,text,text) from public,anon,authenticated;
grant execute on function zos_private.zos_save_state(text,jsonb,bigint),zos_private.zos_set_name(text),zos_private.zos_send_message(text,uuid),zos_private.zos_delete_message(bigint),zos_private.zos_submit_request(text,text,text) to authenticated;
-- Retain all tables already in the publication. Enable only the shared chat
-- here; private progress is read at login or with the explicit Refresh action.
do $$ begin
 if exists(select 1 from pg_publication where pubname='supabase_realtime') then
  if not exists(select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='zos_messages') then
   alter publication supabase_realtime add table public.zos_messages;
  end if;
 else
  create publication supabase_realtime for table public.zos_messages;
 end if;
end $$;
revoke all on sequence public.zos_messages_id_seq, public.zos_content_requests_id_seq from public,anon,authenticated;
-- This existing administrative event trigger must not be an RPC endpoint.
do $$ begin
 if exists(select 1 from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname='public' and p.proname='rls_auto_enable' and p.prorettype='event_trigger'::regtype) then
  revoke execute on function public.rls_auto_enable() from public,anon,authenticated;
 end if;
end $$;
notify pgrst,'reload schema';
commit;
