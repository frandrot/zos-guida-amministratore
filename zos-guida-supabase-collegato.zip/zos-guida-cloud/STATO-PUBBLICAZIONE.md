# Stato della pubblicazione · 7 ottobre 2026

## Completato

Progetto Supabase esistente `zos` (`rdmogdsycnxqwdyrnygw`) collegato.
Applicato realmente lo schema per progressi, profili, messaggi e richieste.
Regole RLS attive, scritture controllate, funzioni privilegiate nello schema privato.
Chat aggiunta alla pubblicazione Realtime. Chiave solo pubblicabile nel client.
I contatori anti-spam non si azzerano cancellando i messaggi.
Il file `public/config.js` e il preset `cloud-public.json` contengono la configurazione verificata.
Nessun nuovo piano o abbonamento acquistato.

## Verificato sul database reale

11 controlli SQL riusciti, riportati in `tests/REPORT-DATABASE-REALE.md`.
Le prove emulano identita JWT e ruoli database in una transazione annullata:
non dimostrano login dal browser, consegna email o WebSocket end-to-end.
Nessun account di prova, messaggio o progresso di prova e rimasto salvato.

## Ancora da completare

Il repository GitHub non e stato pubblicato: l'integrazione restituisce zero
repository/installazioni autorizzate, e la lettura diretta di
`frandrot/zos-guida-amministratore` restituisce 404 (inesistente o non accessibile).
Autorizzare il repository nell'app GitHub collegata a ChatGPT. Un repository
nuovo deve essere inizializzato (ad esempio con un README).
Il pacchetto non contiene un indirizzo inventato di un sito gia online.

Dopo il caricamento, abilitare GitHub Pages con GitHub Actions e impostare
la variabile `ZOS_DEPLOY_ENABLED` a `true`. La configurazione pubblica Supabase
viene letta dal preset incluso; URL/chiave come variabili Actions sono opzionali.
Verificare il risultato della pubblicazione in Actions e Settings > Pages.

Configurare in Supabase Authentication il Site URL e i Redirect URLs con
l'indirizzo effettivo pubblicato. Verificare un login reale, salvataggio e chat
su due sessioni distinte prima di considerare completata la messa online.

Per conferme email e recupero password di utenti non appartenenti al team,
il servizio SMTP predefinito di Supabase non e sufficiente: configurare SMTP
personalizzato. Non disabilitare la conferma email solo per aggirare il limite.
Riferimento: https://supabase.com/docs/guides/auth/auth-smtp
Gestione repository: https://help.openai.com/en/articles/11145903-connecting-github-to-chatgpt

I progressi delle vecchie pagine locali non vengono trasferiti automaticamente:
serve l'importazione dal browser originale o da un export JSON della guida.

## Ulteriori verifiche completate

16 test browser con backend simulato superati. Sintassi di tutti i file JavaScript verificata.
Security Advisors Supabase: nessun avviso restituito.
La generazione della configurazione CI dal preset e stata verificata localmente.
