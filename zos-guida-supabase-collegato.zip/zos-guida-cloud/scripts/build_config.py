"""Write public client configuration. Reject privileged Supabase keys.
Run on GitHub Actions; never needs a database password or service-role key.
"""
from __future__ import annotations
import base64, json, os, re
from pathlib import Path
from urllib.parse import urlparse

def public_key(key: str) -> bool:
    if re.fullmatch(r'sb_publishable_[A-Za-z0-9_-]+', key):
        return True
    try:
        payload = key.split('.')[1]
        data = json.loads(base64.urlsafe_b64decode(payload + '=' * (-len(payload) % 4)))
        return data.get('role') == 'anon'
    except (ValueError, IndexError, UnicodeError, TypeError, AttributeError):
        return False

def main() -> None:
    preset_path = Path(__file__).resolve().parents[1] / 'cloud-public.json'
    preset = json.loads(preset_path.read_text()) if preset_path.exists() else {}
    url = (os.environ.get('SUPABASE_URL') or preset.get('supabaseUrl', '')).strip().rstrip('/')
    key = (os.environ.get('SUPABASE_PUBLISHABLE_KEY') or preset.get('publishableKey', '')).strip()
    parsed = urlparse(url)
    if (parsed.scheme != 'https' or not re.fullmatch(r'[a-z0-9-]+\.supabase\.co', parsed.netloc, re.I)
            or parsed.path or parsed.query or parsed.fragment):
        raise SystemExit('SUPABASE_URL mancante o non valida: usa la URL HTTPS del progetto Supabase.')
    if not public_key(key):
        raise SystemExit('Chiave non valida. Usa solo publishable o anon. Le chiavi secret/service_role sono vietate.')
    config = {'supabaseUrl': url, 'publishableKey': key, 'allowRegistration': True, 'sdkPath': './vendor/supabase.js'}
    path = Path(__file__).resolve().parents[1] / 'public' / 'config.js'
    path.write_text('window.ZOS_CLOUD_CONFIG = Object.freeze(' + json.dumps(config, ensure_ascii=False) + ');\n', encoding='utf-8')
    print('Configurazione pubblica verificata e generata. Nessuna chiave privata utilizzata.')

if __name__ == '__main__':
    main()
