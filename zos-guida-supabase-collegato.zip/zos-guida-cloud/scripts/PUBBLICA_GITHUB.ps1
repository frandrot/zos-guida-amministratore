<# Run after configuring the Supabase database. This script is NOT executed by
   ChatGPT. It asks you to authenticate in your browser and confirm publishing.
   Requires Git and the official GitHub CLI. Never paste a personal token here. #>
param(
  [ValidatePattern('^[A-Za-z0-9_.-]+$')][string]$Repository = 'zos-guida-amministratore',
  [ValidateSet('private','public')][string]$Visibility = 'private'
)
$ErrorActionPreference = 'Stop'
function Check-Exit([string]$Action) { if ($LASTEXITCODE -ne 0) { throw "Operazione non riuscita: $Action" } }
$Root = Split-Path $PSScriptRoot -Parent
Set-Location $Root
if (-not (Get-Command git -ErrorAction SilentlyContinue)) { throw 'Installa Git dal sito ufficiale e riprova.' }
if (-not (Get-Command gh -ErrorAction SilentlyContinue)) { throw 'Installa GitHub CLI dal sito cli.github.com e riprova.' }
if (Test-Path .git) { throw 'Questa cartella contiene gia un repository. Lo script non lo modifica. Usa una nuova estrazione dello ZIP oppure aggiorna il repository esistente con Git.' }
Write-Host 'Accedi a GitHub nel browser. Non viene richiesto alcun token da incollare in chat.'
gh auth status --hostname github.com 2>$null
if ($LASTEXITCODE -ne 0) { gh auth login --hostname github.com --git-protocol https --web; Check-Exit 'accesso GitHub' }
gh auth setup-git --hostname github.com; Check-Exit 'configurazione Git'
$Owner = (gh api user --jq '.login').Trim(); Check-Exit 'lettura account'
$Id = (gh api user --jq '.id').Trim(); Check-Exit 'lettura ID'
$Full = "$Owner/$Repository"
Write-Host "Nuovo repository: $Full ($Visibility)."
Write-Host 'Il codice verra caricato; nessun repository esistente viene sovrascritto.'
Write-Host 'GitHub Pages pubblica un sito accessibile su Internet. Con repository privato verifica che il tuo piano supporti Pages. Nessun upgrade viene effettuato.'
if ((Read-Host 'Digita PUBBLICA per confermare') -cne 'PUBBLICA') { Write-Host 'Annullato.'; exit 0 }
if (Test-Path 'cloud-public.json') {
  $Preset = Get-Content 'cloud-public.json' -Raw | ConvertFrom-Json
  $Url = $Preset.supabaseUrl.Trim().TrimEnd('/')
  $Key = $Preset.publishableKey.Trim()
  Write-Host 'Uso la configurazione pubblica Supabase gia verificata inclusa nel progetto.'
} else {
  $Url = (Read-Host 'URL HTTPS del progetto Supabase').Trim().TrimEnd('/')
  $Key = (Read-Host 'Chiave PUBBLICABILE Supabase (non secret/service_role)').Trim()
}
if ($Url -notmatch '^https://[a-z0-9-]+\.supabase\.co$') { throw 'URL Supabase non valida.' }
$KeyOK = $Key -match '^sb_publishable_[A-Za-z0-9_-]+$'
if (-not $KeyOK) {
  try {
    $Payload = $Key.Split('.')[1].Replace('-','+').Replace('_','/')
    $Payload = $Payload.PadRight($Payload.Length + ((4 - ($Payload.Length % 4)) % 4), '=')
    $Claims = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($Payload)) | ConvertFrom-Json
    $KeyOK = $Claims.role -eq 'anon'
  } catch { $KeyOK = $false }
}
if (-not $KeyOK) { throw 'Sono ammesse solo chiavi pubblicabili o anon. Non usare chiavi segrete.' }
git init -b main; Check-Exit 'inizializzazione repository locale'
git config user.name $Owner; Check-Exit 'autore commit'
git config user.email "$Id+$Owner@users.noreply.github.com"; Check-Exit 'email commit'
git add .; Check-Exit 'preparazione file'
git commit -m 'Guida zOS con console, quiz, account e chat cloud'; Check-Exit 'creazione commit'
gh repo create $Full "--$Visibility" --source . --remote origin --push --description 'Guida z/OS: quiz, console simulata e dati su Supabase'; Check-Exit 'creazione e caricamento repository'
# The initial workflow is skipped until the configuration below is complete.
gh variable set SUPABASE_URL --repo $Full --body $Url; Check-Exit 'variabile URL'
gh variable set SUPABASE_PUBLISHABLE_KEY --repo $Full --body $Key; Check-Exit 'variabile pubblicabile'
'{"build_type":"workflow"}' | gh api --method POST "repos/$Full/pages" --input -
if ($LASTEXITCODE -ne 0) {
  Write-Warning 'I file sono caricati, ma Pages non e stato attivato. Controlla piano e permessi in Settings > Pages. Non viene modificata la visibilita e non viene acquistato alcun piano.'
  exit 1
}
gh variable set ZOS_DEPLOY_ENABLED --repo $Full --body 'true'; Check-Exit 'attivazione pubblicazione'
gh workflow run pages.yml --repo $Full --ref main; Check-Exit 'avvio pubblicazione'
Write-Host 'Pubblicazione AVVIATA, non ancora confermata. Verifica la riuscita nella pagina Actions del repository.'
Write-Host 'Poi apri Settings > Pages > Visit site. Copia quell indirizzo in Supabase Auth > URL Configuration (Site URL e Redirect URLs).'
gh repo view $Full --web
